var	nombre = prompt('Hola, ingrese su nombre')
			alert('Bienvenido '+nombre+' a PS4Info')
		var	edad = prompt('Ahora ingrese su edad')
		var pais = prompt('De que pais?')
		var consola = prompt('Qué consola usas actualmente?')
		var	juego = prompt('Y a que juegas?')


function game() {
	var	letras = ['T', 'R', 'W', 'I', 'U', 'G', 'M', 'Y', 'F', 'P',
	 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K',
	  'E', 'A', 'O']

	 var numero = prompt('Ingrese un numero entre 0 y 25')

	 if(numero<0 || numero>25){
	 	alert("El numero ingresado no es válido")
	 } else {
	 	var letra_elegida = prompt("ingrese una de estas letras (En mayuscula): P,K,F,C,Y,L,M,H,G,V,U,Q,I,S,W,Z,R,J,T,N,B,O,X,A,D,E")

	 	if(letras[numero]==letra_elegida){
	 		alert("Ganaste!! Felicitaciones!")
	 	}

	 	else {
	 		alert("Has perdido")
	 	}

	 }




}